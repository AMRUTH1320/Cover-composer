import { Note } from '../types';

// We access Tone from the global window object injected via CDN
const Tone = window.Tone;

let synth: any = null;
let sequence: any = null;
let isInitialized = false;

// Initialize the audio context and synthesizer
export const initializeAudio = async () => {
  if (isInitialized) return;
  
  await Tone.start();
  
  // Create a polyphonic synth with some effects for a richer sound
  const polySynth = new Tone.PolySynth(Tone.Synth, {
    oscillator: {
      type: "fatsawtooth",
      count: 3,
      spread: 30
    },
    envelope: {
      attack: 0.01,
      decay: 0.1,
      sustain: 0.5,
      release: 1
    }
  }).toDestination();

  // Add some reverb and delay for atmosphere
  const reverb = new Tone.Reverb({ decay: 2.5, preDelay: 0.1 }).toDestination();
  const delay = new Tone.FeedbackDelay("8n", 0.3).toDestination();
  
  polySynth.connect(reverb);
  polySynth.connect(delay);
  
  synth = polySynth;
  isInitialized = true;
};

export const playTrack = async (notes: Note[], bpm: number, onStop: () => void) => {
  if (!isInitialized) await initializeAudio();

  // Stop any previous playback
  if (sequence) {
    sequence.dispose();
    Tone.Transport.stop();
  }

  Tone.Transport.bpm.value = bpm;

  let currentTime = 0;
  // Convert our simple Note structure into Tone.js events
  const toneEvents = notes.map((note) => {
    const event = {
      time: currentTime, // Simple scheduling: sequential
      note: note.pitch,
      duration: note.duration,
      velocity: note.velocity
    };
    
    // Increment time based on duration roughly (approximation for this demo)
    // In a full app, we'd parse "4n" to ticks, but here we let Tone.Transport handle simple relative time if we used a Sequence.
    // However, for precise control from AI output, let's just use a Part or schedule directly.
    // For simplicity with variable durations, we will calculate the transport time.
    
    const durationSeconds = Tone.Time(note.duration).toSeconds();
    currentTime += durationSeconds;
    
    return {
      ...event,
      startTime: event.time // Store the calculated start time
    };
  });

  // Schedule notes
  const part = new Tone.Part((time: any, value: any) => {
    if (value.note) {
      synth.triggerAttackRelease(value.note, value.duration, time, value.velocity);
    }
  }, toneEvents).start(0);

  part.loop = false;
  
  // Calculate total duration to stop
  const totalDuration = toneEvents[toneEvents.length - 1].startTime + Tone.Time(toneEvents[toneEvents.length - 1].duration).toSeconds();
  
  Tone.Transport.start();

  // Schedule stop callback
  Tone.Transport.scheduleOnce(() => {
    Tone.Transport.stop();
    onStop();
  }, totalDuration + 1); // +1 second buffer

  sequence = part;
};

export const stopPlayback = () => {
  if (Tone.Transport.state === 'started') {
    Tone.Transport.stop();
  }
  if (sequence) {
    sequence.dispose();
    sequence = null;
  }
};

export const getTransportState = () => Tone.Transport.state;

export const setVolume = (db: number) => {
  Tone.Destination.volume.value = db;
};

// Helper to get a random waveform for visualizer when no audio is playing
export const getWaveform = () => {
  // Real implementation would use Tone.Analyser
  // For this demo, we'll return dummy data in the React component
  return new Uint8Array(32); 
};