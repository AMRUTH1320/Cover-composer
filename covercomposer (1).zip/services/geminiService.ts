import { GoogleGenAI } from "@google/genai";
import { Genre, Mood, Note } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

interface GeneratedMusicResponse {
  title: string;
  bpm: number;
  description: string;
  notes: Note[];
}

export const generateMusicSequence = async (
  genre: Genre, 
  mood: Mood, 
  tempo: number,
  userDescription?: string
): Promise<GeneratedMusicResponse> => {
  
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    Act as a world-class music composer AI.
    Compose a musical sequence based on the following parameters:
    - Genre: ${genre}
    - Mood: ${mood}
    - Target Tempo: ${tempo} BPM
    - Additional Context: ${userDescription || "None"}

    Your output MUST be a strict JSON object. Do not include markdown formatting (like \`\`\`json).
    
    The JSON structure must be:
    {
      "title": "A creative title for the track",
      "bpm": number (optimized for the genre/mood, close to target),
      "description": "A short 1-sentence description of the generated piece.",
      "notes": [
        {
          "pitch": string (e.g., "C4", "D#5", "A3", or null for a rest/silence),
          "duration": string (Standard musical notation: "1n", "2n", "4n", "4t", "8n", "8t", "16n"),
          "velocity": number (0.5 to 1.0, for dynamics)
        }
      ]
    }

    Constraints:
    - Generate a melody loop of exactly 4 to 8 bars.
    - Ensure the sequence is musically coherent and strictly follows the requested genre scales.
    - For 'Cinematic', use slow, sweeping notes.
    - For 'Techno', use fast, repetitive 16n patterns.
    - For 'Jazz', use syncopation and 7th chords/arpeggios.
    - Total notes should be between 20 and 100.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.8, // Slightly creative
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    const data = JSON.parse(text) as GeneratedMusicResponse;
    return data;
  } catch (error) {
    console.error("Error generating music:", error);
    // Fallback or re-throw
    throw error;
  }
};