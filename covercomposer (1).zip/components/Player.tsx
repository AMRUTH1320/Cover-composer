import React from 'react';
import { GeneratedTrack } from '../types';
import Visualizer from './Visualizer';

interface PlayerProps {
  track: GeneratedTrack | null;
  isPlaying: boolean;
  onPlayPause: () => void;
  onStop: () => void;
}

const Player: React.FC<PlayerProps> = ({ track, isPlaying, onPlayPause, onStop }) => {
  if (!track) {
    return (
      <div className="h-full flex flex-col justify-center items-center bg-zinc-900/50 rounded-2xl border border-zinc-800 border-dashed p-12 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-600">
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" /></svg>
        </div>
        <h3 className="text-zinc-400 font-medium">No track generated yet</h3>
        <p className="text-zinc-600 text-sm max-w-xs">Use the Composer Studio controls to generate your first AI masterpiece.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full space-y-6">
      {/* Track Info */}
      <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 shadow-xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
            <svg className="w-32 h-32 text-indigo-500 transform rotate-12" fill="currentColor" viewBox="0 0 24 24"><path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/></svg>
        </div>
        
        <div className="relative z-10">
          <div className="flex items-start justify-between">
            <div>
              <span className="inline-block px-2 py-1 bg-indigo-500/10 text-indigo-400 text-xs font-bold rounded mb-2 uppercase tracking-wider">{track.genre} • {track.mood}</span>
              <h2 className="text-3xl font-bold text-white mb-1">{track.title}</h2>
              <p className="text-zinc-400 text-sm">{track.description}</p>
            </div>
            <div className="text-right">
               <div className="text-2xl font-mono text-zinc-200">{track.tempo} <span className="text-xs text-zinc-500">BPM</span></div>
               <div className="text-xs text-zinc-500 mt-1">{track.notes.length} NOTES</div>
            </div>
          </div>
        </div>
      </div>

      {/* Visualizer & Controls */}
      <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 shadow-xl flex-1 flex flex-col">
        <div className="flex-1 mb-6 flex flex-col justify-end">
          <Visualizer isPlaying={isPlaying} />
        </div>

        <div className="flex items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <button
              onClick={onPlayPause}
              className={`w-16 h-16 rounded-full flex items-center justify-center transition-all duration-200 ${
                isPlaying 
                  ? 'bg-rose-500 text-white hover:bg-rose-600 shadow-lg shadow-rose-500/20' 
                  : 'bg-green-500 text-white hover:bg-green-600 shadow-lg shadow-green-500/20'
              }`}
            >
              {isPlaying ? (
                 <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
              ) : (
                <svg className="w-6 h-6 translate-x-0.5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              )}
            </button>
            <button
              onClick={onStop}
              className="w-12 h-12 rounded-full bg-zinc-800 text-zinc-400 flex items-center justify-center hover:bg-zinc-700 hover:text-white transition-colors"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 6h12v12H6z"/></svg>
            </button>
          </div>

          <div className="flex-1 bg-zinc-800 h-1.5 rounded-full overflow-hidden">
             {/* Progress bar simulation - indeterminate for this loop-based demo, or we could animate it based on PlaybackState */}
             <div className={`h-full bg-indigo-500 ${isPlaying ? 'w-full animate-pulse' : 'w-0'} transition-all duration-1000`}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Player;