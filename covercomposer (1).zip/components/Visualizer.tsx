import React, { useEffect, useRef } from 'react';

interface VisualizerProps {
  isPlaying: boolean;
  color?: string;
}

const Visualizer: React.FC<VisualizerProps> = ({ isPlaying, color = "bg-purple-500" }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    let animationId: number;
    let step = 0;

    const render = () => {
      // Resize
      const width = canvas.offsetWidth;
      const height = canvas.offsetHeight;
      canvas.width = width;
      canvas.height = height;

      ctx.clearRect(0, 0, width, height);

      const bars = 40;
      const barWidth = width / bars;
      
      for (let i = 0; i < bars; i++) {
        // Simulate frequency data based on math since we don't have direct analyser link easily in this mock
        // If isPlaying, animate wildly. If not, low rumble.
        
        const frequency = isPlaying 
          ? Math.sin(i * 0.5 + step) * Math.cos(i * 0.2 + step * 2) * 0.5 + 0.5 
          : 0.1;
          
        const barHeight = frequency * height * 0.8;
        
        // Gradient
        const gradient = ctx.createLinearGradient(0, height, 0, height - barHeight);
        gradient.addColorStop(0, '#a855f7'); // Purple 500
        gradient.addColorStop(1, '#ec4899'); // Pink 500
        
        ctx.fillStyle = isPlaying ? gradient : '#27272a'; // Zinc 800 for idle
        
        // Draw rounded rect equivalent
        ctx.fillRect(i * barWidth + 2, height - barHeight, barWidth - 4, barHeight);
      }

      step += 0.1;
      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isPlaying, color]);

  return (
    <canvas 
      ref={canvasRef} 
      className="w-full h-48 bg-zinc-900/50 rounded-xl border border-zinc-800"
    />
  );
};

export default Visualizer;