import React from 'react';
import { Genre, Mood } from '../types';

interface ControlsProps {
  genre: Genre;
  setGenre: (g: Genre) => void;
  mood: Mood;
  setMood: (m: Mood) => void;
  tempo: number;
  setTempo: (t: number) => void;
  description: string;
  setDescription: (d: string) => void;
  isGenerating: boolean;
  onGenerate: () => void;
}

const Controls: React.FC<ControlsProps> = ({
  genre, setGenre,
  mood, setMood,
  tempo, setTempo,
  description, setDescription,
  isGenerating, onGenerate
}) => {
  return (
    <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 shadow-xl space-y-6">
      
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-white mb-1">Composer Studio</h2>
        <p className="text-sm text-zinc-400">Configure your AI muse.</p>
      </div>

      {/* Genre & Mood Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Genre Select */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">Genre</label>
          <div className="grid grid-cols-2 gap-2">
            {Object.values(Genre).map((g) => (
              <button
                key={g}
                onClick={() => setGenre(g)}
                className={`px-3 py-2 text-sm rounded-lg border transition-all duration-200 ${
                  genre === g 
                    ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-900/50' 
                    : 'bg-zinc-800 border-zinc-700 text-zinc-400 hover:bg-zinc-700 hover:text-white'
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>

        {/* Mood Select */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">Mood</label>
          <div className="grid grid-cols-2 gap-2">
             {Object.values(Mood).map((m) => (
              <button
                key={m}
                onClick={() => setMood(m)}
                className={`px-3 py-2 text-sm rounded-lg border transition-all duration-200 ${
                  mood === m 
                    ? 'bg-rose-600 border-rose-500 text-white shadow-lg shadow-rose-900/50' 
                    : 'bg-zinc-800 border-zinc-700 text-zinc-400 hover:bg-zinc-700 hover:text-white'
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Tempo Slider */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <label className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">Tempo</label>
          <span className="text-sm font-mono text-indigo-400">{tempo} BPM</span>
        </div>
        <input 
          type="range" 
          min="60" 
          max="180" 
          value={tempo} 
          onChange={(e) => setTempo(Number(e.target.value))}
          className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-indigo-500 hover:accent-indigo-400"
        />
        <div className="flex justify-between text-[10px] text-zinc-600 font-mono">
          <span>Slow (60)</span>
          <span>Fast (180)</span>
        </div>
      </div>

      {/* Description Input */}
      <div className="space-y-2">
        <label className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">Inspiration (Optional)</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="e.g. A futuristic chase scene in the rain..."
          className="w-full bg-zinc-800 border-zinc-700 text-white rounded-lg p-3 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none h-20 placeholder-zinc-600"
        />
      </div>

      {/* Generate Button */}
      <button
        onClick={onGenerate}
        disabled={isGenerating}
        className={`w-full py-4 rounded-xl font-bold text-lg tracking-wide uppercase transition-all duration-300 ${
          isGenerating 
            ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
            : 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:shadow-xl hover:shadow-indigo-500/20 hover:scale-[1.02]'
        }`}
      >
        {isGenerating ? (
          <span className="flex items-center justify-center gap-2">
            <svg className="animate-spin h-5 w-5 text-zinc-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Composing...
          </span>
        ) : (
          'Compose Track'
        )}
      </button>

    </div>
  );
};

export default Controls;