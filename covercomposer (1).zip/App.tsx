import React, { useState, useEffect } from 'react';
import { Genre, Mood, GeneratedTrack, Note } from './types';
import Controls from './components/Controls';
import Player from './components/Player';
import { generateMusicSequence } from './services/geminiService';
import { initializeAudio, playTrack, stopPlayback } from './services/audioEngine';

const App: React.FC = () => {
  const [genre, setGenre] = useState<Genre>(Genre.Cinematic);
  const [mood, setMood] = useState<Mood>(Mood.Epic);
  const [tempo, setTempo] = useState<number>(120);
  const [description, setDescription] = useState<string>('');
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<GeneratedTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [history, setHistory] = useState<GeneratedTrack[]>([]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopPlayback();
    };
  }, []);

  const handleGenerate = async () => {
    setIsGenerating(true);
    stopPlayback();
    setIsPlaying(false);
    
    try {
      // Ensure audio context is unlocked by user interaction before async op
      await initializeAudio();

      const result = await generateMusicSequence(genre, mood, tempo, description);
      
      const newTrack: GeneratedTrack = {
        id: Date.now().toString(),
        title: result.title,
        genre: genre,
        mood: mood,
        tempo: result.bpm,
        notes: result.notes,
        description: result.description,
        createdAt: new Date()
      };

      setCurrentTrack(newTrack);
      setHistory(prev => [newTrack, ...prev]);
    } catch (error) {
      console.error("Failed to generate track", error);
      alert("Something went wrong with the AI composition. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const togglePlay = () => {
    if (!currentTrack) return;

    if (isPlaying) {
      stopPlayback();
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      playTrack(currentTrack.notes, currentTrack.tempo, () => {
        setIsPlaying(false);
      });
    }
  };

  const handleStop = () => {
    stopPlayback();
    setIsPlaying(false);
  };

  const loadFromHistory = (track: GeneratedTrack) => {
    stopPlayback();
    setIsPlaying(false);
    setCurrentTrack(track);
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-white p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <header className="flex justify-between items-center border-b border-zinc-800 pb-6">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/25">
               <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" /></svg>
             </div>
             <h1 className="text-2xl md:text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-400">CoverComposer</h1>
          </div>
          <div className="hidden md:flex items-center gap-4 text-sm text-zinc-500">
            <span>Powered by Gemini 3.0</span>
            <span className="w-1 h-1 bg-zinc-700 rounded-full"></span>
            <span>Tone.js Synthesis</span>
          </div>
        </header>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Controls Section - Left */}
          <div className="lg:col-span-4 space-y-6">
            <Controls 
              genre={genre} setGenre={setGenre}
              mood={mood} setMood={setMood}
              tempo={tempo} setTempo={setTempo}
              description={description} setDescription={setDescription}
              isGenerating={isGenerating}
              onGenerate={handleGenerate}
            />

            {/* History Panel */}
            {history.length > 0 && (
              <div className="bg-zinc-900 rounded-2xl border border-zinc-800 p-6">
                <h3 className="text-sm font-semibold text-zinc-500 uppercase tracking-wider mb-4">Recent Generations</h3>
                <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                  {history.map(track => (
                    <div 
                      key={track.id} 
                      onClick={() => loadFromHistory(track)}
                      className={`p-3 rounded-lg flex items-center justify-between cursor-pointer transition-colors ${
                        currentTrack?.id === track.id ? 'bg-zinc-800 border-l-2 border-indigo-500' : 'hover:bg-zinc-800/50'
                      }`}
                    >
                      <div>
                        <div className="font-medium text-sm text-white">{track.title}</div>
                        <div className="text-xs text-zinc-500">{track.genre} • {track.tempo} BPM</div>
                      </div>
                      <div className="text-xs text-zinc-600">
                        {new Date(track.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Player Section - Right */}
          <div className="lg:col-span-8 h-full min-h-[500px]">
            <Player 
              track={currentTrack}
              isPlaying={isPlaying}
              onPlayPause={togglePlay}
              onStop={handleStop}
            />
          </div>

        </div>
      </div>
    </div>
  );
};

export default App;