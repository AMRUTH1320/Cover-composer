export enum Genre {
  Cinematic = 'Cinematic',
  LoFi = 'Lo-Fi',
  Cyberpunk = 'Cyberpunk',
  Classical = 'Classical',
  Jazz = 'Jazz',
  Techno = 'Techno',
  Ambient = 'Ambient',
  Rock = 'Rock'
}

export enum Mood {
  Epic = 'Epic',
  Melancholic = 'Melancholic',
  Energetic = 'Energetic',
  Chill = 'Chill',
  Dark = 'Dark',
  Hopeful = 'Hopeful',
  Chaotic = 'Chaotic'
}

export interface Note {
  pitch: string | null; // e.g., "C4", "F#5", or null for rest
  duration: string;     // e.g., "4n", "8n", "16n"
  velocity: number;     // 0.0 to 1.0
  time?: string;        // Optional timing if we want precise sequencing
}

export interface GeneratedTrack {
  id: string;
  title: string;
  genre: Genre;
  mood: Mood;
  tempo: number;
  notes: Note[];
  createdAt: Date;
  description?: string;
}

export interface GenerationParams {
  genre: Genre;
  mood: Mood;
  tempo: number;
  description?: string;
}

// Tone.js global type declaration simulation
declare global {
  interface Window {
    Tone: any;
  }
}